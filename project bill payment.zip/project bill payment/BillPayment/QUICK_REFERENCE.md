# Strategy Pattern - Quick Reference Card

## 📦 Package Structure

```
com.example.billpayment.strategy/
├── PaymentStrategy.java          (Interface)
├── PaymentContext.java            (Context Class)
├── CreditCardStrategy.java        (Concrete Strategy)
├── DebitCardStrategy.java         (Concrete Strategy)
├── UPIStrategy.java               (Concrete Strategy)
├── NetBankingStrategy.java        (Concrete Strategy)
├── StrategyPatternDemo.java       (Demo)
└── PaymentStrategyTest.java       (Tests)
```

## 🎯 Strategy Pattern Components

### 1️⃣ **Interface** - PaymentStrategy

```java
public interface PaymentStrategy {
    String processPayment(BillPayment billPayment);
    String getPaymentMethodName();
    boolean validatePayment(BillPayment billPayment);
}
```

### 2️⃣ **Context** - PaymentContext

```java
@Component
public class PaymentContext {
    private PaymentStrategy paymentStrategy;

    public void setPaymentStrategy(PaymentStrategy strategy) {
        this.paymentStrategy = strategy;
    }

    public String executePayment(BillPayment billPayment) {
        return paymentStrategy.processPayment(billPayment);
    }
}
```

### 3️⃣ **Concrete Strategies**

| Strategy           | Fee      | Transaction ID  |
| ------------------ | -------- | --------------- |
| CreditCardStrategy | 2%       | CC-{timestamp}  |
| DebitCardStrategy  | 1%       | DC-{timestamp}  |
| UPIStrategy        | FREE     | UPI-{timestamp} |
| NetBankingStrategy | $5 fixed | NB-{timestamp}  |

## 💡 How to Use in Code

### Client Code (BillPaymentService)

```java
@Service
public class BillPaymentService {
    @Autowired private PaymentContext paymentContext;
    @Autowired private CreditCardStrategy creditCardStrategy;
    @Autowired private DebitCardStrategy debitCardStrategy;
    @Autowired private UPIStrategy upiStrategy;
    @Autowired private NetBankingStrategy netBankingStrategy;

    public BillPayment payBill(BillPayment bill) {
        // Select strategy
        PaymentStrategy strategy = getPaymentStrategy(bill.getPaymentMethod());

        // Set strategy in context
        paymentContext.setPaymentStrategy(strategy);

        // Execute payment
        String result = paymentContext.executePayment(bill);

        // Update status and save
        bill.setStatus(result.contains("successfully") ? "COMPLETED" : "FAILED");
        return billPaymentRepository.save(bill);
    }

    private PaymentStrategy getPaymentStrategy(String method) {
        switch (method.toUpperCase()) {
            case "CREDIT_CARD": return creditCardStrategy;
            case "DEBIT_CARD": return debitCardStrategy;
            case "UPI": return upiStrategy;
            case "NET_BANKING": return netBankingStrategy;
            default: return null;
        }
    }
}
```

## 🔄 Adding New Payment Method (3 Steps)

### Step 1: Create Strategy

```java
@Component
public class NewPaymentStrategy implements PaymentStrategy {
    @Override
    public String processPayment(BillPayment bill) {
        // Your processing logic here
        return "New payment processed successfully!";
    }

    @Override
    public String getPaymentMethodName() {
        return "New Payment Method";
    }

    @Override
    public boolean validatePayment(BillPayment bill) {
        return bill != null && bill.getAmount() > 0;
    }
}
```

### Step 2: Register in Service

```java
@Autowired
private NewPaymentStrategy newPaymentStrategy;

// In getPaymentStrategy() method:
case "NEW_PAYMENT":
    return newPaymentStrategy;
```

### Step 3: Update UI

```html
<option value="NEW_PAYMENT">🆕 New Payment Method</option>
```

## 🧪 Testing Commands

### Run All Tests

```bash
.\mvnw.cmd test
```

### Run Strategy Tests Only

```bash
.\mvnw.cmd test -Dtest=PaymentStrategyTest
```

### Run Demo

```bash
java com.example.billpayment.strategy.StrategyPatternDemo
```

### Compile Project

```bash
.\mvnw.cmd clean compile
```

### Run Application

```bash
.\mvnw.cmd spring-boot:run
```

## 🌐 URLs

| Page       | URL                              |
| ---------- | -------------------------------- |
| Homepage   | http://localhost:8080            |
| Pay Bill   | http://localhost:8080/pay-bill   |
| View Bills | http://localhost:8080/view-bills |

## 📊 Payment Method Comparison

```
┌──────────────┬──────┬──────────────┬─────────────┐
│ Method       │ Fee  │ Processing   │ Best For    │
├──────────────┼──────┼──────────────┼─────────────┤
│ Credit Card  │ 2%   │ Medium       │ Large bills │
│ Debit Card   │ 1%   │ Medium       │ Regular use │
│ UPI          │ FREE │ Instant      │ Quick pay   │
│ Net Banking  │ $5   │ Slow         │ Fixed bills │
└──────────────┴──────┴──────────────┴─────────────┘
```

## ✅ Benefits Checklist

- ✅ Easy to add new payment methods
- ✅ No modification of existing code needed
- ✅ Each strategy is independently testable
- ✅ Clear separation of concerns
- ✅ Follows Open/Closed Principle
- ✅ Follows Single Responsibility Principle
- ✅ Runtime strategy selection
- ✅ No complex if-else chains

## 📁 Documentation Files

1. **STRATEGY_PATTERN_SUMMARY.md** - Complete overview
2. **STRATEGY_PATTERN_README.md** - Detailed documentation
3. **STRATEGY_PATTERN_DIAGRAM.md** - Visual diagrams
4. **QUICK_REFERENCE.md** - This file (quick lookup)

## 🎯 Key Takeaways

1. **Strategy Pattern** = Family of algorithms, each in separate class
2. **Context** = Uses strategies interchangeably
3. **Interface** = Defines contract for all strategies
4. **Concrete Strategies** = Implement specific algorithms
5. **Client** = Selects and uses appropriate strategy

## 💻 Code Snippets

### Basic Usage Example

```java
// Create bill
BillPayment bill = new BillPayment();
bill.setAmount(100.00);
bill.setPaymentMethod("UPI");

// Process with strategy pattern
billPaymentService.payBill(bill);
// Automatically selects UPIStrategy and processes
```

### Manual Strategy Usage

```java
PaymentContext context = new PaymentContext();
context.setPaymentStrategy(new UPIStrategy());
String result = context.executePayment(billPayment);
System.out.println(result);
```

## 🎓 Design Pattern Cheat Sheet

**When to use Strategy Pattern:**

- Multiple algorithms for same task
- Need to switch algorithms at runtime
- Want to avoid complex conditionals
- Algorithms have different implementations

**Components:**

1. Strategy Interface
2. Concrete Strategies (implementations)
3. Context (uses strategies)
4. Client (selects strategy)

**Advantages:**

- Open for extension
- Closed for modification
- Easy to test
- Clean code

---

**Quick Start**: Read STRATEGY_PATTERN_SUMMARY.md first, then explore the code!
**Need Help?**: Check STRATEGY_PATTERN_README.md for detailed explanations
**Visual Learner?**: See STRATEGY_PATTERN_DIAGRAM.md for diagrams

✨ Happy Coding! ✨
