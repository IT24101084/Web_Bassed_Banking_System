# Strategy Pattern - Visual Diagrams

## Class Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                    <<interface>>                                     │
│                    PaymentStrategy                                   │
├─────────────────────────────────────────────────────────────────────┤
│ + processPayment(billPayment: BillPayment): String                  │
│ + getPaymentMethodName(): String                                    │
│ + validatePayment(billPayment: BillPayment): boolean                │
└─────────────────────────────────────────────────────────────────────┘
                              ▲
                              │
                              │ implements
        ┌─────────────────────┼─────────────────────┬──────────────────┐
        │                     │                     │                  │
┌───────┴──────────┐  ┌──────┴───────────┐  ┌──────┴──────┐  ┌────────┴────────┐
│ CreditCard       │  │ DebitCard        │  │    UPI      │  │  NetBanking     │
│ Strategy         │  │ Strategy         │  │  Strategy   │  │   Strategy      │
├──────────────────┤  ├──────────────────┤  ├─────────────┤  ├─────────────────┤
│ - processingFee  │  │ - processingFee  │  │ - noFee     │  │ - fixedFee      │
│   = 2%           │  │   = 1%           │  │   = 0%      │  │   = $5.00       │
└──────────────────┘  └──────────────────┘  └─────────────┘  └─────────────────┘


┌─────────────────────────────────────────────────────────────────────┐
│                      PaymentContext                                  │
│                     (Context Class)                                  │
├─────────────────────────────────────────────────────────────────────┤
│ - paymentStrategy: PaymentStrategy                                  │
├─────────────────────────────────────────────────────────────────────┤
│ + setPaymentStrategy(strategy: PaymentStrategy): void               │
│ + executePayment(billPayment: BillPayment): String                  │
│ + getCurrentPaymentMethod(): String                                 │
└─────────────────────────────────────────────────────────────────────┘
                              │
                              │ uses/delegates
                              ▼
                    [Selected PaymentStrategy]


┌─────────────────────────────────────────────────────────────────────┐
│                    BillPaymentService                                │
│                      (Client)                                        │
├─────────────────────────────────────────────────────────────────────┤
│ - paymentContext: PaymentContext                                    │
│ - creditCardStrategy: CreditCardStrategy                            │
│ - debitCardStrategy: DebitCardStrategy                              │
│ - upiStrategy: UPIStrategy                                          │
│ - netBankingStrategy: NetBankingStrategy                            │
├─────────────────────────────────────────────────────────────────────┤
│ + payBill(billPayment: BillPayment): BillPayment                    │
│ - getPaymentStrategy(paymentMethod: String): PaymentStrategy        │
└─────────────────────────────────────────────────────────────────────┘
```

## Sequence Diagram - Payment Flow

```
User -> Controller -> Service -> Context -> Strategy -> Service -> Repository -> Database

┌────┐  ┌──────────┐  ┌─────────┐  ┌─────────┐  ┌──────────┐  ┌──────────┐  ┌────────┐
│User│  │Controller│  │ Service │  │ Context │  │ Strategy │  │Repository│  │Database│
└─┬──┘  └────┬─────┘  └────┬────┘  └────┬────┘  └────┬─────┘  └────┬─────┘  └───┬────┘
  │          │             │            │            │              │            │
  │ Pay Bill │             │            │            │              │            │
  │─────────>│             │            │            │              │            │
  │          │             │            │            │              │            │
  │          │ payBill()   │            │            │              │            │
  │          │────────────>│            │            │              │            │
  │          │             │            │            │              │            │
  │          │             │getStrategy()│           │              │            │
  │          │             │───────────> │           │              │            │
  │          │             │             │           │              │            │
  │          │             │setStrategy()│           │              │            │
  │          │             │────────────>│           │              │            │
  │          │             │             │           │              │            │
  │          │             │executePayment()         │              │            │
  │          │             │────────────>│           │              │            │
  │          │             │             │           │              │            │
  │          │             │             │processPayment()          │            │
  │          │             │             │──────────>│              │            │
  │          │             │             │           │              │            │
  │          │             │             │<──────────│              │            │
  │          │             │             │  Result   │              │            │
  │          │             │<────────────│           │              │            │
  │          │             │             │           │              │            │
  │          │             │        save()           │              │            │
  │          │             │────────────────────────>│              │            │
  │          │             │                         │              │            │
  │          │             │                         │    INSERT    │            │
  │          │             │                         │─────────────>│            │
  │          │             │                         │              │            │
  │          │             │<────────────────────────│              │            │
  │          │             │         Saved Entity    │              │            │
  │          │<────────────│            │            │              │            │
  │          │  BillPayment│            │            │              │            │
  │<─────────│             │            │            │              │            │
  │ Success  │             │            │            │              │            │
  │          │             │            │            │              │            │
```

## Component Interaction

```
┌──────────────────────────────────────────────────────────────────────┐
│                         WEB LAYER                                     │
│  ┌────────────────┐           ┌─────────────────────────────┐        │
│  │  pay-bill.html │           │ BillPaymentController       │        │
│  │                │──────────>│  - showPayBillForm()        │        │
│  │  [Form with    │           │  - processBillPayment()     │        │
│  │   Payment      │<──────────│                             │        │
│  │   Method       │           └─────────────────────────────┘        │
│  │   Dropdown]    │                         │                        │
│  └────────────────┘                         │                        │
└──────────────────────────────────────────────┼───────────────────────┘
                                               │
┌──────────────────────────────────────────────┼───────────────────────┐
│                      SERVICE LAYER           ▼                        │
│  ┌─────────────────────────────────────────────────────────┐         │
│  │           BillPaymentService                            │         │
│  │  ┌──────────────────────────────────────────────────┐   │         │
│  │  │ 1. Receive BillPayment with paymentMethod        │   │         │
│  │  │ 2. Select appropriate strategy based on method   │   │         │
│  │  │ 3. Set strategy in PaymentContext                │   │         │
│  │  │ 4. Execute payment through context               │   │         │
│  │  │ 5. Update status based on result                 │   │         │
│  │  │ 6. Save to repository                            │   │         │
│  │  └──────────────────────────────────────────────────┘   │         │
│  └─────────────────────────────────────────────────────────┘         │
│                      │                          │                     │
│                      ▼                          ▼                     │
│  ┌──────────────────────────┐   ┌──────────────────────────────┐     │
│  │   PaymentContext         │   │  Strategy Selection          │     │
│  │  - setPaymentStrategy()  │   │  ┌────────────────────────┐  │     │
│  │  - executePayment()      │   │  │ if CREDIT_CARD:        │  │     │
│  └──────────────────────────┘   │  │   -> CreditCardStrategy│  │     │
│                │                 │  │ if DEBIT_CARD:         │  │     │
│                │                 │  │   -> DebitCardStrategy │  │     │
│                ▼                 │  │ if UPI:                │  │     │
│  ┌──────────────────────────┐   │  │   -> UPIStrategy       │  │     │
│  │  Selected Strategy       │   │  │ if NET_BANKING:        │  │     │
│  │  - processPayment()      │<──┼──│   -> NetBankingStrategy│  │     │
│  │  - validatePayment()     │   │  └────────────────────────┘  │     │
│  └──────────────────────────┘   └──────────────────────────────┘     │
└──────────────────────────────────────────────────────────────────────┘
                                               │
┌──────────────────────────────────────────────┼───────────────────────┐
│                   PERSISTENCE LAYER          ▼                        │
│  ┌─────────────────────────────────────────────────────────┐         │
│  │  BillPaymentRepository                                  │         │
│  │  - save()                                               │         │
│  │  - findAll()                                            │         │
│  └─────────────────────────────────────────────────────────┘         │
│                               │                                       │
│                               ▼                                       │
│  ┌─────────────────────────────────────────────────────────┐         │
│  │              MySQL Database                             │         │
│  │          (bill_payments table)                          │         │
│  └─────────────────────────────────────────────────────────┘         │
└──────────────────────────────────────────────────────────────────────┘
```

## Strategy Pattern Benefits Visualization

```
                    WITHOUT Strategy Pattern
┌─────────────────────────────────────────────────────────┐
│              BillPaymentService                         │
│                                                         │
│  public void payBill(BillPayment bill) {                │
│      if (paymentMethod.equals("CREDIT_CARD")) {         │
│          // Credit card logic here                      │
│          // Calculate 2% fee                            │
│          // Process payment                             │
│      } else if (paymentMethod.equals("DEBIT_CARD")) {   │
│          // Debit card logic here                       │
│          // Calculate 1% fee                            │
│          // Process payment                             │
│      } else if (paymentMethod.equals("UPI")) {          │
│          // UPI logic here                              │
│          // No fee                                      │
│          // Process payment                             │
│      } else if (paymentMethod.equals("NET_BANKING")) {  │
│          // Net banking logic here                      │
│          // Fixed $5 fee                                │
│          // Process payment                             │
│      }                                                  │
│      // Violates Open/Closed Principle                 │
│      // Hard to test                                   │
│      // Code duplication                               │
│  }                                                      │
└─────────────────────────────────────────────────────────┘

                    WITH Strategy Pattern
┌─────────────────────────────────────────────────────────┐
│              BillPaymentService                         │
│                                                         │
│  public void payBill(BillPayment bill) {                │
│      PaymentStrategy strategy =                         │
│          getPaymentStrategy(bill.getPaymentMethod());   │
│      paymentContext.setPaymentStrategy(strategy);       │
│      String result = context.executePayment(bill);      │
│      // Clean, simple, extensible                       │
│      // Each strategy is tested independently           │
│      // Easy to add new payment methods                 │
│  }                                                      │
└─────────────────────────────────────────────────────────┘

            Each strategy in separate class
┌──────────────┐  ┌──────────────┐  ┌──────────┐  ┌─────────────┐
│ CreditCard   │  │ DebitCard    │  │   UPI    │  │ NetBanking  │
│ Strategy     │  │ Strategy     │  │ Strategy │  │  Strategy   │
├──────────────┤  ├──────────────┤  ├──────────┤  ├─────────────┤
│ 2% fee logic │  │ 1% fee logic │  │ No fee   │  │ $5 fee logic│
└──────────────┘  └──────────────┘  └──────────┘  └─────────────┘
```

## Adding New Strategy - Step by Step

```
Step 1: Create New Strategy Class
┌─────────────────────────────────────────────────┐
│  @Component                                     │
│  public class WalletStrategy                    │
│         implements PaymentStrategy {            │
│                                                 │
│      @Override                                  │
│      public String processPayment(...) {        │
│          // Wallet-specific logic               │
│      }                                          │
│      // ... other methods                       │
│  }                                              │
└─────────────────────────────────────────────────┘
                    │
                    ▼
Step 2: Register in Service
┌─────────────────────────────────────────────────┐
│  @Autowired                                     │
│  private WalletStrategy walletStrategy;         │
│                                                 │
│  private PaymentStrategy getStrategy(String m){ │
│      switch(m) {                                │
│          // ... existing cases                  │
│          case "WALLET":                         │
│              return walletStrategy;             │
│      }                                          │
│  }                                              │
└─────────────────────────────────────────────────┘
                    │
                    ▼
Step 3: Update UI
┌─────────────────────────────────────────────────┐
│  <select name="paymentMethod">                  │
│      <!-- existing options -->                  │
│      <option value="WALLET">                    │
│          💰 Wallet                              │
│      </option>                                  │
│  </select>                                      │
└─────────────────────────────────────────────────┘
                    │
                    ▼
            ✅ DONE! No other changes needed
```

## Real-World Usage Flow

```
┌─────────┐
│  User   │
└────┬────┘
     │ 1. Selects "Pay Bill"
     ▼
┌──────────────────┐
│  pay-bill.html   │
└────┬─────────────┘
     │ 2. Fills form:
     │    - Account: ACC123
     │    - Bill Type: ELECTRICITY
     │    - Amount: $100
     │    - Payment Method: UPI ← Important!
     ▼
┌─────────────────────────┐
│  BillPaymentController  │
└────┬────────────────────┘
     │ 3. Calls service.payBill()
     ▼
┌─────────────────────────┐
│  BillPaymentService     │
│  ┌──────────────────┐   │
│  │ getStrategy("UPI")│   │
│  └────────┬─────────┘   │
│           ▼             │
│  ┌──────────────────┐   │
│  │ Returns          │   │
│  │ UPIStrategy      │   │
│  └────────┬─────────┘   │
└───────────┼─────────────┘
            │
            ▼
┌─────────────────────────┐
│   PaymentContext        │
│  setStrategy(UPI)       │
└────┬────────────────────┘
     │
     ▼
┌─────────────────────────┐
│   UPIStrategy           │
│  processPayment()       │
│  - Validates            │
│  - No fee calculation   │
│  - Generates TX ID      │
│  - Returns success msg  │
└────┬────────────────────┘
     │
     ▼
┌─────────────────────────┐
│  Save to Database       │
│  Status: COMPLETED      │
└────┬────────────────────┘
     │
     ▼
┌─────────────────────────┐
│  Show Success to User   │
│  "UPI payment           │
│   processed             │
│   successfully!"        │
└─────────────────────────┘
```
