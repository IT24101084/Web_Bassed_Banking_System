# Strategy Pattern Implementation

## Overview

This document explains the **Strategy Pattern** implementation in the Bill Payment Management System.

## What is the Strategy Pattern?

The Strategy Pattern is a behavioral design pattern that:

- Defines a family of algorithms (payment methods)
- Encapsulates each algorithm in separate classes
- Makes them interchangeable at runtime
- Lets the algorithm vary independently from clients that use it

## Components

### 1. **Strategy Interface** (`PaymentStrategy`)

Defines the contract that all payment strategies must follow.

**Location**: `src/main/java/com/example/billpayment/strategy/PaymentStrategy.java`

**Methods**:

- `String processPayment(BillPayment billPayment)` - Process the payment
- `String getPaymentMethodName()` - Get payment method name
- `boolean validatePayment(BillPayment billPayment)` - Validate payment details

### 2. **Concrete Strategy Classes**

Each class implements a specific payment method:

#### a) `CreditCardStrategy`

- **Processing Fee**: 2% of amount
- **Transaction ID Format**: `CC-{timestamp}`
- **Use Case**: Credit card payments with higher processing fees

#### b) `DebitCardStrategy`

- **Processing Fee**: 1% of amount
- **Transaction ID Format**: `DC-{timestamp}`
- **Use Case**: Debit card payments with lower fees

#### c) `UPIStrategy`

- **Processing Fee**: No fee (free)
- **Transaction ID Format**: `UPI-{timestamp}`
- **Use Case**: UPI payments (fastest and cheapest)

#### d) `NetBankingStrategy`

- **Processing Fee**: Fixed $5
- **Transaction ID Format**: `NB-{timestamp}`
- **Use Case**: Direct bank transfers

### 3. **Context Class** (`PaymentContext`)

Manages and executes payment strategies.

**Location**: `src/main/java/com/example/billpayment/strategy/PaymentContext.java`

**Responsibilities**:

- Holds a reference to the current payment strategy
- Delegates payment processing to the strategy
- Provides a unified interface for executing payments

## Architecture Diagram

```
┌─────────────────────────────────────────────────────┐
│              PaymentStrategy (Interface)            │
│  + processPayment(BillPayment): String             │
│  + getPaymentMethodName(): String                   │
│  + validatePayment(BillPayment): boolean            │
└─────────────────────────────────────────────────────┘
                         ▲
                         │ implements
         ┌───────────────┼───────────────┬──────────────┐
         │               │               │              │
┌────────┴────────┐ ┌────┴──────┐ ┌─────┴──────┐ ┌────┴──────────┐
│ CreditCard      │ │ DebitCard │ │    UPI     │ │  NetBanking   │
│ Strategy        │ │ Strategy  │ │  Strategy  │ │   Strategy    │
└─────────────────┘ └───────────┘ └────────────┘ └───────────────┘

┌─────────────────────────────────────────────────────┐
│           PaymentContext (Context Class)            │
│  - paymentStrategy: PaymentStrategy                 │
│  + setPaymentStrategy(PaymentStrategy): void        │
│  + executePayment(BillPayment): String              │
│  + getCurrentPaymentMethod(): String                │
└─────────────────────────────────────────────────────┘
                         │ uses
                         ▼
            [Delegates to selected strategy]
```

## How It Works

### 1. **Strategy Selection**

```java
// In BillPaymentService.java
private PaymentStrategy getPaymentStrategy(String paymentMethod) {
    switch (paymentMethod.toUpperCase()) {
        case "CREDIT_CARD":
            return creditCardStrategy;
        case "DEBIT_CARD":
            return debitCardStrategy;
        case "UPI":
            return upiStrategy;
        case "NET_BANKING":
            return netBankingStrategy;
        default:
            return null;
    }
}
```

### 2. **Payment Execution**

```java
// Set the strategy
paymentContext.setPaymentStrategy(strategy);

// Execute payment using selected strategy
String result = paymentContext.executePayment(billPayment);
```

### 3. **Strategy in Action**

Each strategy processes the payment differently:

- **Credit Card**: Charges 2% fee
- **Debit Card**: Charges 1% fee
- **UPI**: No fees
- **Net Banking**: Fixed $5 fee

## Benefits

### 1. **Open/Closed Principle**

- Open for extension: Easy to add new payment methods
- Closed for modification: No need to change existing code

### 2. **Single Responsibility**

- Each strategy class has one job: handle one payment method
- Separation of concerns

### 3. **Runtime Flexibility**

- Payment method can be changed at runtime
- No need for complex if-else or switch statements

### 4. **Testability**

- Each strategy can be tested independently
- Easy to mock for unit testing

### 5. **Maintainability**

- Changes to one payment method don't affect others
- Clear, organized code structure

## Adding a New Payment Method

To add a new payment method (e.g., Wallet):

1. **Create a new strategy class**:

```java
@Component
public class WalletStrategy implements PaymentStrategy {
    @Override
    public String processPayment(BillPayment billPayment) {
        // Wallet-specific logic
    }

    @Override
    public String getPaymentMethodName() {
        return "Wallet";
    }

    @Override
    public boolean validatePayment(BillPayment billPayment) {
        // Validation logic
    }
}
```

2. **Add to BillPaymentService**:

```java
@Autowired
private WalletStrategy walletStrategy;

// Add to switch statement
case "WALLET":
    return walletStrategy;
```

3. **Update HTML form**:

```html
<option value="WALLET">💰 Wallet</option>
```

That's it! No other code needs to be modified.

## Usage Example

```java
// Create bill payment
BillPayment bill = new BillPayment();
bill.setAccountNumber("ACC123");
bill.setAmount(100.00);
bill.setPaymentMethod("UPI");

// Service automatically selects and uses UPI strategy
billPaymentService.payBill(bill);
```

## Files Modified/Created

### Created:

- `PaymentStrategy.java` - Strategy interface
- `CreditCardStrategy.java` - Concrete strategy
- `DebitCardStrategy.java` - Concrete strategy
- `UPIStrategy.java` - Concrete strategy
- `NetBankingStrategy.java` - Concrete strategy
- `PaymentContext.java` - Context class
- `StrategyPatternDemo.java` - Demo class

### Modified:

- `BillPayment.java` - Added paymentMethod field
- `BillPaymentService.java` - Integrated strategy pattern
- `pay-bill.html` - Added payment method dropdown
- `view-bills.html` - Display payment method

## Testing the Implementation

Run the demo class:

```bash
java com.example.billpayment.strategy.StrategyPatternDemo
```

Or use the web application:

1. Start the application: `mvnw spring-boot:run`
2. Navigate to: http://localhost:8080/pay-bill
3. Select different payment methods to see strategies in action
4. View results at: http://localhost:8080/view-bills

## Summary

The Strategy Pattern implementation provides:

- ✅ Clean separation of payment logic
- ✅ Easy to add new payment methods
- ✅ Runtime flexibility
- ✅ Better testability
- ✅ Follows SOLID principles
- ✅ Production-ready code
