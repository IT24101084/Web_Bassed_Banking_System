# 02_Context - Strategy Pattern Context Class

## 📁 Contents

This folder contains the **Context Class** component of the Strategy Pattern.

## 📄 Files

- `PaymentContext.java` - The context class that manages and executes payment strategies

## 🎯 Purpose

The PaymentContext class serves as:

- **Strategy Manager**: Holds reference to current payment strategy
- **Execution Delegate**: Delegates payment processing to selected strategy
- **Runtime Selector**: Allows switching strategies at runtime
- **Unified Interface**: Provides consistent API for clients

## 💡 Key Features

- ✅ Clean, commented code for easy understanding
- ✅ Strategy validation before execution
- ✅ Error handling for missing strategies
- ✅ Spring component for dependency injection

## 🔄 How it Works

1. Client sets desired payment strategy using `setPaymentStrategy()`
2. Client calls `executePayment()` with payment details
3. Context validates strategy selection and payment data
4. Context delegates processing to the selected strategy
5. Returns result from strategy execution

## 🔗 Related Components

- **Interface**: `01_Interface/PaymentStrategy.java`
- **Concrete Strategies**: `03_Concrete_Strategies/*.java`
- **Integration**: `05_Integration/BillPaymentService.java`

## 📝 Usage Example

```java
PaymentContext context = new PaymentContext();
context.setPaymentStrategy(new CreditCardStrategy());
String result = context.executePayment(billPayment);
```
