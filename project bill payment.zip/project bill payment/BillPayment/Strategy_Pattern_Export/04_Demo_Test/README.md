# 04_Demo_Test - Demonstration and Testing Files

## 📁 Contents

This folder contains **demo and testing** files for the Strategy Pattern implementation.

## 📄 Files

- `StrategyPatternDemo.java` - Live demonstration of how Strategy Pattern works
- `PaymentStrategyTest.java` - Comprehensive unit tests for all strategies

## 🎯 Purpose

### 🎮 Demo File (`StrategyPatternDemo.java`)

- **Interactive Example**: Shows Strategy Pattern in action
- **Multiple Strategies**: Demonstrates all 4 payment methods
- **Clear Output**: Shows different processing results
- **Educational**: Explains key observations and benefits

### 🧪 Test File (`PaymentStrategyTest.java`)

- **Complete Coverage**: Tests all 4 payment strategies
- **Validation Testing**: Tests payment validation rules
- **Error Scenarios**: Tests missing strategy and invalid payments
- **Strategy Switching**: Tests runtime strategy changes

## ✅ Test Results

All tests pass successfully:

- ✅ Credit Card Strategy Test
- ✅ Debit Card Strategy Test
- ✅ UPI Strategy Test
- ✅ Net Banking Strategy Test
- ✅ Strategy Validation Test
- ✅ Context Without Strategy Test
- ✅ Strategy Switching Test

## 🚀 How to Run

### Run Demo:

```bash
java com.example.billpayment.strategy.StrategyPatternDemo
```

### Run Tests:

```bash
# All tests
.\mvnw.cmd test

# Strategy tests only
.\mvnw.cmd test -Dtest=PaymentStrategyTest
```

## 📊 Demo Output Example

The demo shows each strategy processing the same payment with different results:

- Credit Card: 2% fee charged
- Debit Card: 1% fee charged
- UPI: No fee (recommended!)
- Net Banking: $5 fixed fee

## 🔗 Related Components

- **Strategies**: `03_Concrete_Strategies/*.java`
- **Context**: `02_Context/PaymentContext.java`
- **Interface**: `01_Interface/PaymentStrategy.java`

## 💡 Benefits Demonstrated

- Runtime strategy selection
- Different processing logic per strategy
- Easy extensibility
- Clean separation of concerns
