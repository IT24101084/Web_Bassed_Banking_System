# 01_Interface - Strategy Pattern Interface

## 📁 Contents

This folder contains the **Strategy Interface** component of the Strategy Pattern.

## 📄 Files

- `PaymentStrategy.java` - The core interface that defines the contract for all payment strategies

## 🎯 Purpose

The interface provides a common contract that all concrete payment strategies must implement:

- `processPayment()` - Process payment with method-specific logic
- `getPaymentMethodName()` - Get payment method display name
- `validatePayment()` - Validate payment before processing

## 💡 Key Features

- ✅ Clear, short comments for better understanding
- ✅ Well-defined method signatures
- ✅ Standardized return types and parameters
- ✅ JavaDoc documentation

## 🔗 Related Components

- **Context**: `02_Context/PaymentContext.java`
- **Concrete Strategies**: `03_Concrete_Strategies/*.java`
- **Integration**: `05_Integration/BillPaymentService.java`

## 📝 Usage

This interface is implemented by all concrete payment strategies and used by the PaymentContext to ensure consistent behavior across all payment methods.
