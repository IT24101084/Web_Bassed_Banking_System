package com.example.billpayment.strategy;

import com.example.billpayment.entity.BillPayment;

/**
 * Strategy Pattern Demonstration Class
 * 
 * This demonstrates how the Strategy Pattern works with different payment
 * methods.
 * The Strategy Pattern allows selecting payment algorithms at runtime.
 * 
 * Components:
 * 1. Strategy Interface (PaymentStrategy) - Defines the contract
 * 2. Concrete Strategies (CreditCardStrategy, DebitCardStrategy, UPIStrategy,
 * NetBankingStrategy)
 * 3. Context Class (PaymentContext) - Uses the strategies
 * 
 * Benefits:
 * - Open/Closed Principle: Easy to add new payment methods without modifying
 * existing code
 * - Single Responsibility: Each strategy handles one payment method
 * - Runtime flexibility: Can change payment strategy dynamically
 */
public class StrategyPatternDemo {

    public static void main(String[] args) {
        // Create a sample bill payment
        BillPayment billPayment = new BillPayment();
        billPayment.setAccountNumber("ACC123456");
        billPayment.setBillType("ELECTRICITY");
        billPayment.setBillerName("City Power Company");
        billPayment.setAmount(150.00);

        // Create context
        PaymentContext context = new PaymentContext();

        System.out.println("=== Strategy Pattern Demo ===\n");
        System.out.println("Bill Details:");
        System.out.println("Account: " + billPayment.getAccountNumber());
        System.out.println("Bill Type: " + billPayment.getBillType());
        System.out.println("Amount: $" + billPayment.getAmount());
        System.out.println("\n--- Testing Different Payment Strategies ---\n");

        // Test 1: Credit Card Strategy
        System.out.println("1. Using Credit Card Strategy:");
        context.setPaymentStrategy(new CreditCardStrategy());
        String result1 = context.executePayment(billPayment);
        System.out.println(result1);
        System.out.println();

        // Test 2: Debit Card Strategy
        System.out.println("2. Using Debit Card Strategy:");
        context.setPaymentStrategy(new DebitCardStrategy());
        String result2 = context.executePayment(billPayment);
        System.out.println(result2);
        System.out.println();

        // Test 3: UPI Strategy
        System.out.println("3. Using UPI Strategy:");
        context.setPaymentStrategy(new UPIStrategy());
        String result3 = context.executePayment(billPayment);
        System.out.println(result3);
        System.out.println();

        // Test 4: Net Banking Strategy
        System.out.println("4. Using Net Banking Strategy:");
        context.setPaymentStrategy(new NetBankingStrategy());
        String result4 = context.executePayment(billPayment);
        System.out.println(result4);
        System.out.println();

        System.out.println("=== Demo Complete ===");
        System.out.println("\nKey Observations:");
        System.out.println("- Same context, different strategies");
        System.out.println("- Each strategy has its own processing logic");
        System.out.println("- Easy to switch between payment methods at runtime");
        System.out.println("- Adding new payment method requires only creating a new strategy class");
    }
}
