package com.example.billpayment.strategy;

import com.example.billpayment.entity.BillPayment;
import org.springframework.stereotype.Component;

/**
 * Context Class - Manages and executes payment strategies
 * Allows runtime selection of payment methods without exposing strategy details
 */
@Component
public class PaymentContext {

    // Currently selected payment strategy
    private PaymentStrategy paymentStrategy;

    /**
     * Set payment strategy to use
     * 
     * @param paymentStrategy Strategy implementation to execute
     */
    public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    /**
     * Execute payment using current strategy
     * 
     * @param billPayment Payment details to process
     * @return Payment result message
     */
    public String executePayment(BillPayment billPayment) {
        // Ensure strategy is selected
        if (paymentStrategy == null) {
            return "Error: No payment strategy selected";
        }

        // Validate before processing
        if (!paymentStrategy.validatePayment(billPayment)) {
            return "Error: Payment validation failed";
        }

        // Delegate to selected strategy
        return paymentStrategy.processPayment(billPayment);
    }

    /**
     * Get current payment method name
     * 
     * @return Payment method name or "Not Set" if no strategy is selected
     */
    public String getCurrentPaymentMethod() {
        return paymentStrategy != null ? paymentStrategy.getPaymentMethodName() : "Not Set";
    }
}
