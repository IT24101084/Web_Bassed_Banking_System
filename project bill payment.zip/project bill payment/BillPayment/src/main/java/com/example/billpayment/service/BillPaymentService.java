package com.example.billpayment.service;

import com.example.billpayment.entity.BillPayment;
import com.example.billpayment.repository.BillPaymentRepository;
import com.example.billpayment.strategy.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class BillPaymentService {

    @Autowired
    private BillPaymentRepository billPaymentRepository;

    @Autowired
    private PaymentContext paymentContext;

    @Autowired
    private CreditCardStrategy creditCardStrategy;

    @Autowired
    private DebitCardStrategy debitCardStrategy;

    @Autowired
    private UPIStrategy upiStrategy;

    @Autowired
    private NetBankingStrategy netBankingStrategy;

    // CREATE - Pay a new bill using Strategy Pattern
    public BillPayment payBill(BillPayment billPayment) {
        billPayment.setPaymentDate(LocalDateTime.now());

        // Select payment strategy based on payment method
        PaymentStrategy strategy = getPaymentStrategy(billPayment.getPaymentMethod());

        if (strategy == null) {
            billPayment.setStatus("FAILED");
            return billPaymentRepository.save(billPayment);
        }

        // Set the strategy in context and execute payment
        paymentContext.setPaymentStrategy(strategy);
        String paymentResult = paymentContext.executePayment(billPayment);

        // Set status based on payment result
        if (paymentResult.contains("successfully")) {
            billPayment.setStatus("COMPLETED");
        } else {
            billPayment.setStatus("FAILED");
        }

        return billPaymentRepository.save(billPayment);
    }

    // Helper method to get the appropriate payment strategy
    private PaymentStrategy getPaymentStrategy(String paymentMethod) {
        if (paymentMethod == null) {
            return null;
        }

        switch (paymentMethod.toUpperCase()) {
            case "CREDIT_CARD":
                return creditCardStrategy;
            case "DEBIT_CARD":
                return debitCardStrategy;
            case "UPI":
                return upiStrategy;
            case "NET_BANKING":
                return netBankingStrategy;
            default:
                return null;
        }
    }

    // READ - Get all bills
    public List<BillPayment> getAllBills() {
        return billPaymentRepository.findAll();
    }

    // READ - Get bills by account number
    public List<BillPayment> getBillsByAccount(String accountNumber) {
        return billPaymentRepository.findByAccountNumber(accountNumber);
    }

    // READ - Get bill by ID
    public Optional<BillPayment> getBillById(Long id) {
        return billPaymentRepository.findById(id);
    }

    // DELETE - Remove a bill payment record
    public void deleteBill(Long id) {
        billPaymentRepository.deleteById(id);
    }
}