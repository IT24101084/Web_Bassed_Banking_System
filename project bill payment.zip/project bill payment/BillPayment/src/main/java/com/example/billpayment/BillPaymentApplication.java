package com.example.billpayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillPaymentApplication {

    public static void main(String[] args) {
        SpringApplication.run(BillPaymentApplication.class, args);
    }

}
