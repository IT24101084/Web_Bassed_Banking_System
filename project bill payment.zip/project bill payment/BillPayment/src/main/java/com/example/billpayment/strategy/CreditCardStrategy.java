package com.example.billpayment.strategy;

import com.example.billpayment.entity.BillPayment;
import org.springframework.stereotype.Component;

/**
 * Credit Card Payment Strategy - Processes payments with 2% fee
 * High processing cost but widely accepted payment method
 */
@Component
public class CreditCardStrategy implements PaymentStrategy {

    @Override
    public String processPayment(BillPayment billPayment) {
        // Validate payment first
        if (!validatePayment(billPayment)) {
            return "Payment validation failed for Credit Card";
        }

        // Calculate processing fee (2% of amount)
        double processingFee = billPayment.getAmount() * 0.02;
        double totalAmount = billPayment.getAmount() + processingFee;

        // Generate transaction confirmation
        return String.format("Credit Card payment processed successfully! " +
                "Amount: $%.2f, Processing Fee: $%.2f, Total: $%.2f. " +
                "Transaction ID: CC-%d",
                billPayment.getAmount(), processingFee, totalAmount,
                System.currentTimeMillis());
    }

    @Override
    public String getPaymentMethodName() {
        return "Credit Card";
    }

    @Override
    public boolean validatePayment(BillPayment billPayment) {
        // Basic payment validation rules
        return billPayment != null &&
                billPayment.getAmount() != null &&
                billPayment.getAmount() > 0 &&
                billPayment.getAccountNumber() != null &&
                !billPayment.getAccountNumber().isEmpty();
    }
}
