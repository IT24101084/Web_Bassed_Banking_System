package com.example.billpayment.controller;

import com.example.billpayment.entity.BillPayment;
import com.example.billpayment.service.BillPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
public class BillPaymentController {

    @Autowired
    private BillPaymentService billPaymentService;

    // Home page - Index page with logo and background
    @GetMapping("/")
    public String homePage(Model model) {
        model.addAttribute("message", "Welcome to Bill Payment Management System");
        return "index";
    }

    // Show bill payment form
    @GetMapping("/pay-bill")
    public String showPayBillForm(Model model) {
        model.addAttribute("billPayment", new BillPayment());
        return "pay-bill";
    }

    // Process bill payment
    @PostMapping("/pay-bill")
    public String processBillPayment(@ModelAttribute BillPayment billPayment, Model model) {
        billPaymentService.payBill(billPayment);
        model.addAttribute("success", "Bill payment completed successfully!");
        model.addAttribute("billPayment", new BillPayment()); // Reset form
        return "pay-bill";
    }

    // View all bill payments
    @GetMapping("/view-bills")
    public String viewAllBills(Model model) {
        List<BillPayment> bills = billPaymentService.getAllBills();
        model.addAttribute("bills", bills);
        return "view-bills";
    }

    // Delete bill payment
    @GetMapping("/delete-bill/{id}")
    public String deleteBill(@PathVariable Long id) {
        billPaymentService.deleteBill(id);
        return "redirect:/view-bills";
    }
}