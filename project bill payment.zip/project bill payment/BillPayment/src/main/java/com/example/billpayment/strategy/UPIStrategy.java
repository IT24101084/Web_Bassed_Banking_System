package com.example.billpayment.strategy;

import com.example.billpayment.entity.BillPayment;
import org.springframework.stereotype.Component;

/**
 * UPI Payment Strategy - Free payment processing
 * Fast, secure, and no processing fees
 */
@Component
public class UPIStrategy implements PaymentStrategy {

    @Override
    public String processPayment(BillPayment billPayment) {
        // Validate payment first
        if (!validatePayment(billPayment)) {
            return "Payment validation failed for UPI";
        }

        // UPI processing (no fees charged)
        return String.format("UPI payment processed successfully! " +
                "Amount: $%.2f (No processing fee). " +
                "Transaction ID: UPI-%d",
                billPayment.getAmount(),
                System.currentTimeMillis());
    }

    @Override
    public String getPaymentMethodName() {
        return "UPI";
    }

    @Override
    public boolean validatePayment(BillPayment billPayment) {
        // Basic payment validation rules
        return billPayment != null &&
                billPayment.getAmount() != null &&
                billPayment.getAmount() > 0 &&
                billPayment.getAccountNumber() != null &&
                !billPayment.getAccountNumber().isEmpty();
    }
}