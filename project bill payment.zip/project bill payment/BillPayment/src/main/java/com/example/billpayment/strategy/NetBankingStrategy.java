package com.example.billpayment.strategy;

import com.example.billpayment.entity.BillPayment;
import org.springframework.stereotype.Component;

/**
 * Net Banking Payment Strategy - Fixed $5 processing fee
 * Traditional banking method with fixed cost
 */
@Component
public class NetBankingStrategy implements PaymentStrategy {

    @Override
    public String processPayment(BillPayment billPayment) {
        // Validate payment first
        if (!validatePayment(billPayment)) {
            return "Payment validation failed for Net Banking";
        }

        // Calculate fixed processing fee
        double processingFee = 5.00; // Fixed $5 fee
        double totalAmount = billPayment.getAmount() + processingFee;

        // Generate transaction confirmation
        return String.format("Net Banking payment processed successfully! " +
                "Amount: $%.2f, Processing Fee: $%.2f, Total: $%.2f. " +
                "Transaction ID: NB-%d",
                billPayment.getAmount(), processingFee, totalAmount,
                System.currentTimeMillis());
    }

    @Override
    public String getPaymentMethodName() {
        return "Net Banking";
    }

    @Override
    public boolean validatePayment(BillPayment billPayment) {
        // Basic payment validation rules
        return billPayment != null &&
                billPayment.getAmount() != null &&
                billPayment.getAmount() > 0 &&
                billPayment.getAccountNumber() != null &&
                !billPayment.getAccountNumber().isEmpty();
    }
}