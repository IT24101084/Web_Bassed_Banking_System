package com.example.billpayment.strategy;

import com.example.billpayment.entity.BillPayment;
import org.springframework.stereotype.Component;

/**
 * Debit Card Payment Strategy - Processes payments with 1% fee
 * Lower cost alternative to credit cards
 */
@Component
public class DebitCardStrategy implements PaymentStrategy {

    @Override
    public String processPayment(BillPayment billPayment) {
        // Validate payment first
        if (!validatePayment(billPayment)) {
            return "Payment validation failed for Debit Card";
        }

        // Calculate processing fee (1% of amount)
        double processingFee = billPayment.getAmount() * 0.01;
        double totalAmount = billPayment.getAmount() + processingFee;

        // Generate transaction confirmation
        return String.format("Debit Card payment processed successfully! " +
                "Amount: $%.2f, Processing Fee: $%.2f, Total: $%.2f. " +
                "Transaction ID: DC-%d",
                billPayment.getAmount(), processingFee, totalAmount,
                System.currentTimeMillis());
    }

    @Override
    public String getPaymentMethodName() {
        return "Debit Card";
    }

    @Override
    public boolean validatePayment(BillPayment billPayment) {
        // Basic payment validation rules
        return billPayment != null &&
                billPayment.getAmount() != null &&
                billPayment.getAmount() > 0 &&
                billPayment.getAccountNumber() != null &&
                !billPayment.getAccountNumber().isEmpty();
    }
}