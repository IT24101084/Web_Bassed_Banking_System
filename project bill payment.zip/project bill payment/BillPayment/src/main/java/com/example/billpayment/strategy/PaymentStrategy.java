package com.example.billpayment.strategy;

import com.example.billpayment.entity.BillPayment;

/**
 * Strategy Interface - Contract for all payment methods
 * Defines common operations that every payment strategy must implement
 */
public interface PaymentStrategy {
    /**
     * Process payment with method-specific logic
     * 
     * @param billPayment Payment details to process
     * @return Success/failure message with transaction details
     */
    String processPayment(BillPayment billPayment);

    /**
     * Get payment method display name
     * 
     * @return Human-readable payment method name
     */
    String getPaymentMethodName();

    /**
     * Validate payment before processing
     * 
     * @param billPayment Payment to validate
     * @return true if payment is valid, false otherwise
     */
    boolean validatePayment(BillPayment billPayment);
}
