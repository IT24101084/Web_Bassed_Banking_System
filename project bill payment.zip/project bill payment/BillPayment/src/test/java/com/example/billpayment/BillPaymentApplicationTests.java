package com.example.billpayment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillPaymentApplicationTests {

    @Test
    void contextLoads() {
    }

}
