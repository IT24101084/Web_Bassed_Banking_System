package com.example.billpayment.strategy;

import com.example.billpayment.entity.BillPayment;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Payment Strategy Pattern
 */
public class PaymentStrategyTest {

    private BillPayment billPayment;
    private PaymentContext context;

    @BeforeEach
    public void setUp() {
        billPayment = new BillPayment();
        billPayment.setAccountNumber("TEST123");
        billPayment.setBillType("ELECTRICITY");
        billPayment.setBillerName("Test Biller");
        billPayment.setAmount(100.00);

        context = new PaymentContext();
    }

    @Test
    public void testCreditCardStrategy() {
        CreditCardStrategy strategy = new CreditCardStrategy();
        context.setPaymentStrategy(strategy);

        String result = context.executePayment(billPayment);

        assertNotNull(result);
        assertTrue(result.contains("Credit Card payment processed successfully"));
        assertTrue(result.contains("Processing Fee"));
        assertEquals("Credit Card", context.getCurrentPaymentMethod());
    }

    @Test
    public void testDebitCardStrategy() {
        DebitCardStrategy strategy = new DebitCardStrategy();
        context.setPaymentStrategy(strategy);

        String result = context.executePayment(billPayment);

        assertNotNull(result);
        assertTrue(result.contains("Debit Card payment processed successfully"));
        assertEquals("Debit Card", context.getCurrentPaymentMethod());
    }

    @Test
    public void testUPIStrategy() {
        UPIStrategy strategy = new UPIStrategy();
        context.setPaymentStrategy(strategy);

        String result = context.executePayment(billPayment);

        assertNotNull(result);
        assertTrue(result.contains("UPI payment processed successfully"));
        assertTrue(result.contains("No processing fee"));
        assertEquals("UPI", context.getCurrentPaymentMethod());
    }

    @Test
    public void testNetBankingStrategy() {
        NetBankingStrategy strategy = new NetBankingStrategy();
        context.setPaymentStrategy(strategy);

        String result = context.executePayment(billPayment);

        assertNotNull(result);
        assertTrue(result.contains("Net Banking payment processed successfully"));
        assertEquals("Net Banking", context.getCurrentPaymentMethod());
    }

    @Test
    public void testStrategyValidation() {
        CreditCardStrategy strategy = new CreditCardStrategy();

        // Valid payment
        assertTrue(strategy.validatePayment(billPayment));

        // Invalid payment - null amount
        BillPayment invalidBill = new BillPayment();
        invalidBill.setAccountNumber("TEST123");
        assertFalse(strategy.validatePayment(invalidBill));

        // Invalid payment - negative amount
        invalidBill.setAmount(-50.00);
        assertFalse(strategy.validatePayment(invalidBill));
    }

    @Test
    public void testContextWithoutStrategy() {
        PaymentContext emptyContext = new PaymentContext();
        String result = emptyContext.executePayment(billPayment);

        assertEquals("Error: No payment strategy selected", result);
        assertEquals("Not Set", emptyContext.getCurrentPaymentMethod());
    }

    @Test
    public void testStrategySwitching() {
        // Start with Credit Card
        context.setPaymentStrategy(new CreditCardStrategy());
        assertEquals("Credit Card", context.getCurrentPaymentMethod());

        // Switch to UPI
        context.setPaymentStrategy(new UPIStrategy());
        assertEquals("UPI", context.getCurrentPaymentMethod());

        // Switch to Net Banking
        context.setPaymentStrategy(new NetBankingStrategy());
        assertEquals("Net Banking", context.getCurrentPaymentMethod());
    }
}
